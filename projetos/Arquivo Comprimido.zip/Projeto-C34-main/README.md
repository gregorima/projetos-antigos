Adaptado para um jogo de demolição de prédio. ;)
